#!/bin/sh

cd /data/oh-llama.cpp

echo "========== focus 专注状态 =========="
./lib/ld-linux-aarch64.so.1 \
--library-path /data/oh-llama.cpp/lib:/data/oh-llama.cpp/lib/lib \
./build/bin/llama-cli \
-m /data/models/qwen2.5-1.5b-instruct-q4_k_m-00001-of-00001.gguf \
-no-cnv \
--no-display-prompt \
--temp 0.25 \
--top-p 0.75 \
--repeat-penalty 1.25 \
-n 28 \
-p "<|im_start|>system
你是脑电健康建议生成器。
根据状态标签、状态说明和建议方向，生成一句中文建议。
只输出一句建议。
不要解释脑电指标。
不要提到Alpha、Beta、Theta。
不要建议改变脑电指标。
不要诊断疾病。
不要分点。
不要照抄示例。
语气专业、温和、自然。
不超过24字。

示例：
state=focus，状态说明=专注状态较好
建议：专注状态较好，适合继续短时任务。

state=focus，状态说明=注意力较集中
建议：保持当前节奏，适合完成关键任务。

state=chill，状态说明=当前状态较放松
建议：当前状态较放松，适合低压力活动。

state=chill，状态说明=身心状态较平稳
建议：保持平稳呼吸，享受当前放松状态。

state=fatigue，状态说明=当前略显疲劳
建议：当前略显疲劳，建议闭眼休息片刻。

state=fatigue，状态说明=精力有所下降
建议：先短暂休息，再逐步恢复任务节奏。

state=stress，状态说明=当前状态略显紧张
建议：放慢呼吸节奏，给自己片刻缓冲。

state=stress，状态说明=身心略有紧绷
建议：暂停高强度任务，做几轮深呼吸。
<|im_end|>
<|im_start|>user
state=focus
状态说明=专注状态较好
建议方向=继续短时任务
请生成一句专业温和的建议，不要照抄示例。
<|im_end|>
<|im_start|>assistant
建议："

echo ""
echo "========== chill 放松状态 =========="
./lib/ld-linux-aarch64.so.1 \
--library-path /data/oh-llama.cpp/lib:/data/oh-llama.cpp/lib/lib \
./build/bin/llama-cli \
-m /data/models/qwen2.5-1.5b-instruct-q4_k_m-00001-of-00001.gguf \
-no-cnv \
--no-display-prompt \
--temp 0.25 \
--top-p 0.75 \
--repeat-penalty 1.25 \
-n 28 \
-p "<|im_start|>system
你是脑电健康建议生成器。
根据状态标签、状态说明和建议方向，生成一句中文建议。
只输出一句建议。
不要解释脑电指标。
不要提到Alpha、Beta、Theta。
不要建议改变脑电指标。
不要诊断疾病。
不要分点。
不要照抄示例。
语气专业、温和、自然。
不超过24字。

示例：
state=focus，状态说明=专注状态较好
建议：专注状态较好，适合继续短时任务。

state=focus，状态说明=注意力较集中
建议：保持当前节奏，适合完成关键任务。

state=chill，状态说明=当前状态较放松
建议：当前状态较放松，适合低压力活动。

state=chill，状态说明=身心状态较平稳
建议：保持平稳呼吸，享受当前放松状态。

state=fatigue，状态说明=当前略显疲劳
建议：当前略显疲劳，建议闭眼休息片刻。

state=fatigue，状态说明=精力有所下降
建议：先短暂休息，再逐步恢复任务节奏。

state=stress，状态说明=当前状态略显紧张
建议：放慢呼吸节奏，给自己片刻缓冲。

state=stress，状态说明=身心略有紧绷
建议：暂停高强度任务，做几轮深呼吸。
<|im_end|>
<|im_start|>user
state=chill
状态说明=当前状态较放松
建议方向=低压力活动或平稳呼吸
请生成一句专业温和的建议，不要照抄示例。
<|im_end|>
<|im_start|>assistant
建议："

echo ""
echo "========== fatigue 疲劳状态 =========="
./lib/ld-linux-aarch64.so.1 \
--library-path /data/oh-llama.cpp/lib:/data/oh-llama.cpp/lib/lib \
./build/bin/llama-cli \
-m /data/models/qwen2.5-1.5b-instruct-q4_k_m-00001-of-00001.gguf \
-no-cnv \
--no-display-prompt \
--temp 0.25 \
--top-p 0.75 \
--repeat-penalty 1.25 \
-n 28 \
-p "<|im_start|>system
你是脑电健康建议生成器。
根据状态标签、状态说明和建议方向，生成一句中文建议。
只输出一句建议。
不要解释脑电指标。
不要提到Alpha、Beta、Theta。
不要建议改变脑电指标。
不要诊断疾病。
不要分点。
不要照抄示例。
语气专业、温和、自然。
不超过24字。

示例：
state=focus，状态说明=专注状态较好
建议：专注状态较好，适合继续短时任务。

state=focus，状态说明=注意力较集中
建议：保持当前节奏，适合完成关键任务。

state=chill，状态说明=当前状态较放松
建议：当前状态较放松，适合低压力活动。

state=chill，状态说明=身心状态较平稳
建议：保持平稳呼吸，享受当前放松状态。

state=fatigue，状态说明=当前略显疲劳
建议：当前略显疲劳，建议闭眼休息片刻。

state=fatigue，状态说明=精力有所下降
建议：先短暂休息，再逐步恢复任务节奏。

state=stress，状态说明=当前状态略显紧张
建议：放慢呼吸节奏，给自己片刻缓冲。

state=stress，状态说明=身心略有紧绷
建议：暂停高强度任务，做几轮深呼吸。
<|im_end|>
<|im_start|>user
state=fatigue
状态说明=当前略显疲劳
建议方向=短暂休息或闭眼放松
请生成一句专业温和的建议，不要照抄示例。
<|im_end|>
<|im_start|>assistant
建议："

echo ""
echo "========== stress 紧张状态 =========="
./lib/ld-linux-aarch64.so.1 \
--library-path /data/oh-llama.cpp/lib:/data/oh-llama.cpp/lib/lib \
./build/bin/llama-cli \
-m /data/models/qwen2.5-1.5b-instruct-q4_k_m-00001-of-00001.gguf \
-no-cnv \
--no-display-prompt \
--temp 0.25 \
--top-p 0.75 \
--repeat-penalty 1.25 \
-n 28 \
-p "<|im_start|>system
你是脑电健康建议生成器。
根据状态标签、状态说明和建议方向，生成一句中文建议。
只输出一句建议。
不要解释脑电指标。
不要提到Alpha、Beta、Theta。
不要建议改变脑电指标。
不要诊断疾病。
不要分点。
不要照抄示例。
语气专业、温和、自然。
不超过24字。

示例：
state=focus，状态说明=专注状态较好
建议：专注状态较好，适合继续短时任务。

state=focus，状态说明=注意力较集中
建议：保持当前节奏，适合完成关键任务。

state=chill，状态说明=当前状态较放松
建议：当前状态较放松，适合低压力活动。

state=chill，状态说明=身心状态较平稳
建议：保持平稳呼吸，享受当前放松状态。

state=fatigue，状态说明=当前略显疲劳
建议：当前略显疲劳，建议闭眼休息片刻。

state=fatigue，状态说明=精力有所下降
建议：先短暂休息，再逐步恢复任务节奏。

state=stress，状态说明=当前状态略显紧张
建议：放慢呼吸节奏，给自己片刻缓冲。

state=stress，状态说明=身心略有紧绷
建议：暂停高强度任务，做几轮深呼吸。
<|im_end|>
<|im_start|>user
state=stress
状态说明=当前状态略显紧张
建议方向=放慢呼吸节奏或短暂放松
请生成一句专业温和的建议，不要照抄示例。
<|im_end|>
<|im_start|>assistant
建议："

echo ""
echo "========== 全部测试结束 =========="
