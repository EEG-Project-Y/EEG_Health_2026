#!/bin/sh
export LD_LIBRARY_PATH=/data/oh-llama.cpp/lib:$LD_LIBRARY_PATH
/data/oh-llama.cpp/lib/ld-linux-aarch64.so.1 ./build/bin/llama-cli \
  -m /data/models/qwen2.5-0.5b-instruct-q4_k_m.gguf \
  -p "<|im_start|>user\n$1<|im_end|>\n<|im_start|>assistant\n" \
  -n 200 \
  -t 3 \
  -no-cnv
